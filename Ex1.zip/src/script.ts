import { Patinete } from "./Patinete";
import PromptSync = require('prompt-sync');

const prompt = PromptSync();

const rodas = Number(prompt('Digite a quantidade de rodas do patinete: '));
const cor = prompt('Diga qual é a cor do patinete: ');
const tamanho = Number(prompt('Digite o tamanho do patinete: '));

const patinete: Patinete = new Patinete({
    rodas,
    cor,
    tamanho
});

console.log(`\nO patinete tem ${patinete.rodas} rodas`);
console.log(`A cor do patinete é ${patinete.cor}`);
console.log(`O tamanho do patinete é ${patinete.tamanho}`);
patinete.movimento;
