interface NewPatinete{
    rodas: number;
    cor: string;
    tamanho: number;
}

class Patinete{
    public rodas: number;
    public cor: string;
    public tamanho: number;

    constructor({rodas, cor, tamanho}: NewPatinete){
        this.rodas = rodas;
        this.cor = cor;
        this.tamanho = tamanho;
    }
    public movimento(): void{
        console.log('O patinete está em movimento');
    }
}
export{Patinete};