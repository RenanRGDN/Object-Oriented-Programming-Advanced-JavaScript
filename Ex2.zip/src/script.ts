import { Conta } from "./conta";

const conta: Conta = new Conta({
    nome: 'Renan',
    valor: 10000,
    cpf: 37489537843
});

console.clear();
console.log(`Nome do seu usuário: ${conta.getNome()}`);
console.log(`Valor na conta: R$ ${conta.getvalor()}`);
console.log(`CPF do usuário: ${conta.getCpf()}`);