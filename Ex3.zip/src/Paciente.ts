class Paciente{
    private nome: string;
    private dInternacao: string;
    private sexo: string;
    private idade: number;

    constructor(nome: string,  dInternacao: string, sexo: string, idade: number){
        this.nome = nome;
        this.dInternacao =  dInternacao;
        this.sexo = sexo;
        this.idade = idade;
    }
    public getNome(): string{
        return this.nome;
    }
    public getData(): string{
        return this.dInternacao;
    }
    public getSexo(): string{
        return this.sexo;
    }
    public getIdade(): number{
        return this.idade;
    }
}
export{Paciente};